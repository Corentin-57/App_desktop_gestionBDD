
package com.mycompany.test_afficherbdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connexion {
            Connection conn = null;
    public Connexion() {      
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/tennis?useSSL=false&useLegacyDatetimeCode=false&serverTimezone=Europe/Paris",
					"root", "Mesemu_3");             
            System.out.println("Connexion à la base donnée réussi");
        }catch (SQLException e) {
            System.out.println(e);
        }
    }
    Connection getConnexion(){
        return conn;
    }
}
