/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.test_afficherbdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Utilisateur
 */
public class Connexion {
            Connection conn = null;
    public Connexion() {      
        try{
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/tennis?useSSL=false&useLegacyDatetimeCode=false&serverTimezone=Europe/Paris",
					"root", "Mesemu_3");             
            System.out.println("Connexion à la base donnée réussi");
        }catch (SQLException e) {
            System.out.println(e);
        }
    }
    Connection getConnexion(){
        return conn;
    }
}
