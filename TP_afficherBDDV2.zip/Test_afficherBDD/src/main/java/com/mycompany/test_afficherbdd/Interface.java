/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.test_afficherbdd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Interface extends javax.swing.JFrame {

    Statement statement;
    Connexion conn = new Connexion();
    DefaultTableModel model_Joueurs;
    DefaultTableModel model_Tournois;
    DefaultTableModel model_Matchs;
    DefaultTableModel model_Epreuves;
    
    public Interface() {
        initComponents();
       
        model_Joueurs = (DefaultTableModel)tb_Joueurs.getModel();
        model_Tournois = (DefaultTableModel) tb_Tournois.getModel();
        model_Matchs = (DefaultTableModel) tb_Matchs.getModel();
        model_Epreuves = (DefaultTableModel) tb_Epreuves.getModel();
        listeJoueurs();
    }
    
    public void listeJoueurs(){
        
        try{
            Connection conn = null;
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/tennis?useSSL=false&useLegacyDatetimeCode=false&serverTimezone=Europe/Paris",
					"root", "Mesemu_3");             
            System.out.println("Connexion à la base donnée réussi");
            String query1 = "SELECT * FROM joueur";
            Statement statement = conn.createStatement();            
            ResultSet rs = statement.executeQuery(query1);
            
            while(rs.next()){
                model_Joueurs.insertRow(model_Joueurs.getRowCount(), new Object[] {rs.getInt("ID"), rs.getString("NOM"), rs.getString("PRENOM"), rs.getString("SEXE")});
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }   
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        tbJoueurs = new javax.swing.JTable();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        labelNom_joueurs = new javax.swing.JLabel();
        tfNom_joueurs = new javax.swing.JTextField();
        labelPrenom_joueurs = new javax.swing.JLabel();
        tfPrenom_joueurs = new javax.swing.JTextField();
        labelSexe_joueurs = new javax.swing.JLabel();
        tfSexe_joueurs = new javax.swing.JTextField();
        btAjouter_joueurs = new javax.swing.JButton();
        btEditer_joueurs = new javax.swing.JButton();
        btSupprimer_joueurs = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        sexeJoueurs = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        tfRechercher_joueurs = new javax.swing.JTextField();
        labelRechercher_joueurs = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tb_Joueurs = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        labelNom_tournois = new javax.swing.JLabel();
        tfNom_tournois = new javax.swing.JTextField();
        labelCode_tournois = new javax.swing.JLabel();
        tfCode_tournois = new javax.swing.JTextField();
        btAjouter_tournois = new javax.swing.JButton();
        btEditer_tournois = new javax.swing.JButton();
        btSupprimer_tournois = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        tfRechercher_tournois = new javax.swing.JTextField();
        labelRechercher_tournois = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tb_Tournois = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        combo_matchs = new javax.swing.JComboBox<>();
        labelSexe_matchs = new javax.swing.JLabel();
        labelRechercher_matchs = new javax.swing.JLabel();
        tfRechercher_matchs = new javax.swing.JTextField();
        labelStatut_matchs = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tb_Matchs = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        labelAnnee_epreuves = new javax.swing.JLabel();
        tfAnnee_epreuves = new javax.swing.JTextField();
        lbType_epreuves = new javax.swing.JLabel();
        tfType_epreuves = new javax.swing.JTextField();
        btRechercher_epreuve = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tb_Epreuves = new javax.swing.JTable();

        tbJoueurs.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nom", "Prénom", "Sexe"
            }
        ));
        jScrollPane2.setViewportView(tbJoueurs);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.CardLayout());

        labelNom_joueurs.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labelNom_joueurs.setText("Nom :");

        tfNom_joueurs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfNom_joueursActionPerformed(evt);
            }
        });

        labelPrenom_joueurs.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labelPrenom_joueurs.setText("Prenom :");

        tfPrenom_joueurs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfPrenom_joueursActionPerformed(evt);
            }
        });

        labelSexe_joueurs.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labelSexe_joueurs.setText("Sexe :");

        tfSexe_joueurs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfSexe_joueursActionPerformed(evt);
            }
        });

        btAjouter_joueurs.setText("Ajouter");
        btAjouter_joueurs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAjouter_joueursActionPerformed(evt);
            }
        });

        btEditer_joueurs.setText("Editer");
        btEditer_joueurs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEditer_joueursActionPerformed(evt);
            }
        });

        btSupprimer_joueurs.setText("Supprimer");
        btSupprimer_joueurs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSupprimer_joueursActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(labelPrenom_joueurs)
                                .addGap(18, 18, 18))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(labelNom_joueurs, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfPrenom_joueurs, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel9Layout.createSequentialGroup()
                                .addComponent(tfNom_joueurs, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(133, 133, 133)
                                .addComponent(labelSexe_joueurs, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tfSexe_joueurs, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(108, 108, 108)
                        .addComponent(btAjouter_joueurs)
                        .addGap(66, 66, 66)
                        .addComponent(btEditer_joueurs)
                        .addGap(69, 69, 69)
                        .addComponent(btSupprimer_joueurs)))
                .addContainerGap(55, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelNom_joueurs)
                    .addComponent(tfNom_joueurs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelSexe_joueurs)
                    .addComponent(tfSexe_joueurs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelPrenom_joueurs)
                    .addComponent(tfPrenom_joueurs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btAjouter_joueurs)
                    .addComponent(btEditer_joueurs)
                    .addComponent(btSupprimer_joueurs))
                .addContainerGap(39, Short.MAX_VALUE))
        );

        sexeJoueurs.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "..", "H", "F" }));
        sexeJoueurs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sexeJoueursActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Sexe :");

        tfRechercher_joueurs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfRechercher_joueursActionPerformed(evt);
            }
        });
        tfRechercher_joueurs.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tfRechercher_joueursKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tfRechercher_joueursKeyTyped(evt);
            }
        });

        labelRechercher_joueurs.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labelRechercher_joueurs.setText("Rechercher :");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap(66, Short.MAX_VALUE)
                .addComponent(labelRechercher_joueurs, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfRechercher_joueurs, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(75, 75, 75)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(sexeJoueurs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(101, 101, 101))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sexeJoueurs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(tfRechercher_joueurs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelRechercher_joueurs))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        tb_Joueurs.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nom", "Prénom", "Sexe"
            }
        ));
        tb_Joueurs.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_JoueursMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tb_Joueurs);
        if (tb_Joueurs.getColumnModel().getColumnCount() > 0) {
            tb_Joueurs.getColumnModel().getColumn(2).setHeaderValue("Prénom");
            tb_Joueurs.getColumnModel().getColumn(3).setHeaderValue("Sexe");
        }

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane4)
                    .addContainerGap()))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(409, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(263, 263, 263)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(29, Short.MAX_VALUE)))
        );

        jTabbedPane1.addTab("Joueurs", jPanel1);

        labelNom_tournois.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labelNom_tournois.setText("Nom :");

        tfNom_tournois.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfNom_tournoisActionPerformed(evt);
            }
        });

        labelCode_tournois.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labelCode_tournois.setText("Code : ");

        tfCode_tournois.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfCode_tournoisActionPerformed(evt);
            }
        });

        btAjouter_tournois.setText("Ajouter");
        btAjouter_tournois.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAjouter_tournoisActionPerformed(evt);
            }
        });

        btEditer_tournois.setText("Editer");
        btEditer_tournois.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEditer_tournoisActionPerformed(evt);
            }
        });

        btSupprimer_tournois.setText("Supprimer");
        btSupprimer_tournois.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSupprimer_tournoisActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel10Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(labelNom_tournois, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(tfNom_tournois, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(labelCode_tournois)
                        .addGap(30, 30, 30)
                        .addComponent(tfCode_tournois, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel10Layout.createSequentialGroup()
                        .addGap(108, 108, 108)
                        .addComponent(btAjouter_tournois)
                        .addGap(66, 66, 66)
                        .addComponent(btEditer_tournois)
                        .addGap(69, 69, 69)
                        .addComponent(btSupprimer_tournois)))
                .addContainerGap(77, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfNom_tournois, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelNom_tournois)
                    .addComponent(tfCode_tournois, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelCode_tournois))
                .addGap(46, 46, 46)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btAjouter_tournois)
                    .addComponent(btEditer_tournois)
                    .addComponent(btSupprimer_tournois))
                .addContainerGap(39, Short.MAX_VALUE))
        );

        tfRechercher_tournois.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfRechercher_tournoisActionPerformed(evt);
            }
        });
        tfRechercher_tournois.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tfRechercher_tournoisKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tfRechercher_tournoisKeyTyped(evt);
            }
        });

        labelRechercher_tournois.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labelRechercher_tournois.setText("Rechercher :");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(labelRechercher_tournois, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tfRechercher_tournois, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(194, 194, 194))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfRechercher_tournois, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelRechercher_tournois))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        tb_Tournois.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Nom", "Code"
            }
        ));
        tb_Tournois.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_TournoisMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tb_Tournois);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane5))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Tournois", jPanel3);

        combo_matchs.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "...", "Vainqueurs", "Finalistes" }));
        combo_matchs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_matchsActionPerformed(evt);
            }
        });

        labelSexe_matchs.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N

        labelRechercher_matchs.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labelRechercher_matchs.setText("Rechercher : ");

        tfRechercher_matchs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfRechercher_matchsActionPerformed(evt);
            }
        });
        tfRechercher_matchs.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tfRechercher_matchsKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                tfRechercher_matchsKeyTyped(evt);
            }
        });

        labelStatut_matchs.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labelStatut_matchs.setText("Statut:");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(labelRechercher_matchs)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfRechercher_matchs, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(labelSexe_matchs, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                        .addComponent(labelStatut_matchs, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)))
                .addComponent(combo_matchs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelRechercher_matchs)
                    .addComponent(combo_matchs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelSexe_matchs)
                    .addComponent(tfRechercher_matchs, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelStatut_matchs))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        tb_Matchs.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nom", "Prénom", "Sexe"
            }
        ));
        jScrollPane6.setViewportView(tb_Matchs);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 541, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 576, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Matchs", jPanel4);

        labelAnnee_epreuves.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        labelAnnee_epreuves.setText("Année :");

        tfAnnee_epreuves.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfAnnee_epreuvesActionPerformed(evt);
            }
        });

        lbType_epreuves.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbType_epreuves.setText("Type épreuve :");

        tfType_epreuves.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfType_epreuvesActionPerformed(evt);
            }
        });

        btRechercher_epreuve.setText("Rechercher");
        btRechercher_epreuve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btRechercher_epreuveActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(labelAnnee_epreuves, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(tfAnnee_epreuves, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52)
                .addComponent(lbType_epreuves)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfType_epreuves, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btRechercher_epreuve)
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelAnnee_epreuves)
                    .addComponent(tfAnnee_epreuves, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbType_epreuves)
                    .addComponent(tfType_epreuves, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btRechercher_epreuve))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tb_Epreuves.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nom", "Prénom"
            }
        ));
        jScrollPane3.setViewportView(tb_Epreuves);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 541, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 542, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Epreuves", jPanel2);

        getContentPane().add(jTabbedPane1, "card2");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tfAnnee_epreuvesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfAnnee_epreuvesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfAnnee_epreuvesActionPerformed

    private void tfType_epreuvesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfType_epreuvesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfType_epreuvesActionPerformed

    private void btRechercher_epreuveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btRechercher_epreuveActionPerformed
        try{
            model_Epreuves = (DefaultTableModel)tb_Epreuves.getModel();
            model_Epreuves.setRowCount(0);
                System.out.println("A");
                PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("SELECT NOM, PRENOM FROM joueur, match_tennis, epreuve WHERE epreuve.ID = match_tennis.ID_EPREUVE AND epreuve.ANNEE = ? AND epreuve.TYPE_EPREUVE = ? AND (match_tennis.ID_VAINQUEUR = joueur.ID OR match_tennis.ID_FINALISTE = joueur.ID);");
                int annee = Integer.parseInt(tfAnnee_epreuves.getText());
                preparedStatement.setInt(1, annee );
                preparedStatement.setString(2, tfType_epreuves.getText());
                ResultSet rs = preparedStatement.executeQuery();
                System.out.println("B");
                while(rs.next()){
                    System.out.println("C");
                    model_Epreuves.insertRow(model_Epreuves.getRowCount(), new Object[] {rs.getString("NOM"), rs.getString("PRENOM")});
                }
                
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erreur d'enregistrement réessayer");
            System.err.println(e);
        }
    }//GEN-LAST:event_btRechercher_epreuveActionPerformed

    private void tfNom_joueursActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfNom_joueursActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfNom_joueursActionPerformed

    private void tfPrenom_joueursActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfPrenom_joueursActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfPrenom_joueursActionPerformed

    private void tfSexe_joueursActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfSexe_joueursActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfSexe_joueursActionPerformed

    private void btAjouter_joueursActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAjouter_joueursActionPerformed
        
        try{
            PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("INSERT INTO joueur (NOM, PRENOM, SEXE) VALUES (?, ?, ?)");
            //preparedStatement.setString(1, tfId_joueurs.getText());
            preparedStatement.setString(1, tfNom_joueurs.getText());
            preparedStatement.setString(2, tfPrenom_joueurs.getText());
            preparedStatement.setString(3, tfSexe_joueurs.getText());

            preparedStatement.executeUpdate();
            
            preparedStatement = conn.getConnexion().prepareStatement("SELECT MAX(ID) FROM joueur"); //Je recupère l'id le plus élevé soit le dernier joueur enregistré
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()){
                int id = rs.getInt(1);
                model_Joueurs.insertRow(model_Joueurs.getRowCount(), new Object[] {id, tfNom_joueurs.getText(), tfPrenom_joueurs.getText(), tfSexe_joueurs.getText()});
            }
   
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erreur d'enregistrement réessayer");
            System.err.println(e);
    }
    }//GEN-LAST:event_btAjouter_joueursActionPerformed

    private void btEditer_joueursActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEditer_joueursActionPerformed
       
            try{

                int ligneSelect = tb_Joueurs.getSelectedRow();
                String idString = String.valueOf(tb_Joueurs.getValueAt(ligneSelect, 0));
                int id = Integer.parseInt(idString);
            
                PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("UPDATE joueur SET NOM=?, PRENOM=?, SEXE=? WHERE ID=?");
                String nom = tfNom_joueurs.getText();
                String prenom = tfPrenom_joueurs.getText();
                String sexe = tfSexe_joueurs.getText();
                
                preparedStatement.setString(1, nom);
                preparedStatement.setString(2, prenom);
                preparedStatement.setString(3, sexe);
                preparedStatement.setInt(4, id);
                
                preparedStatement.executeUpdate();
                
                model_Joueurs.setValueAt(tfNom_joueurs.getText(), tb_Joueurs.getSelectedRow(), 1);
                model_Joueurs.setValueAt(tfPrenom_joueurs.getText(), tb_Joueurs.getSelectedRow(), 2);
                model_Joueurs.setValueAt(tfSexe_joueurs.getText(), tb_Joueurs.getSelectedRow(), 3);
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erreur d'enregistrement réessayer");
            System.err.println(e);
        }
    }//GEN-LAST:event_btEditer_joueursActionPerformed

    private void btSupprimer_joueursActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSupprimer_joueursActionPerformed

        try{
            int ligneSelect = tb_Joueurs.getSelectedRow();
            String idString = String.valueOf(tb_Joueurs.getValueAt(ligneSelect, 0));
            int id = Integer.parseInt(idString);
            PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("DELETE FROM joueur WHERE ID=? ");
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
            
            model_Joueurs.removeRow(tb_Joueurs.getSelectedRow());
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erreur d'enregistrement réessayer");
            System.err.println(e);
        }
    }//GEN-LAST:event_btSupprimer_joueursActionPerformed

    private void sexeJoueursActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sexeJoueursActionPerformed
        try{
            //Effacer les lignes du tableau actuel
            //DefaultTableModel model1 = (DefaultTableModel)tb_Joueurs.getModel();
            model_Joueurs.setRowCount(0);
                    
            
            PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("SELECT * FROM joueur WHERE SEXE=?");
            String sexe = (String)sexeJoueurs.getSelectedItem();
            preparedStatement.setString(1, sexe);
            ResultSet rs = preparedStatement.executeQuery();
            
            while(rs.next()){
                model_Joueurs.insertRow(model_Joueurs.getRowCount(), new Object[] {rs.getInt("ID"), rs.getString("NOM"), rs.getString("PRENOM"), rs.getString("SEXE")});
            }
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erreur d'enregistrement réessayer");
            System.err.println(e);
        }
    }//GEN-LAST:event_sexeJoueursActionPerformed

    private void tfRechercher_joueursActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfRechercher_joueursActionPerformed

    }//GEN-LAST:event_tfRechercher_joueursActionPerformed

    private void tfRechercher_joueursKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfRechercher_joueursKeyTyped
                                
        try{
            //Effacer les lignes du tableau actuel
            //DefaultTableModel model_Joueurs = (DefaultTableModel)tb_Joueurs.getModel();
            model_Joueurs.setRowCount(0);
            String sexe = String.valueOf(sexeJoueurs.getSelectedItem());
            if (sexe.equals("..")){
                System.out.println("A");
                PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("SELECT * FROM joueur WHERE NOM LIKE ? OR PRENOM LIKE ?");
                String mot = tfRechercher_joueurs.getText();
                preparedStatement.setString(1, "%" + mot + "%");
                preparedStatement.setString(2, "%" + mot + "%");
                ResultSet rs = preparedStatement.executeQuery();
                while(rs.next()){
                    model_Joueurs.insertRow(model_Joueurs.getRowCount(), new Object[] {rs.getInt("ID"), rs.getString("NOM"), rs.getString("PRENOM"), rs.getString("SEXE")});
                }
            }else{
                System.out.println("B");
                PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("SELECT * FROM joueur WHERE (NOM LIKE ? OR PRENOM LIKE ?) AND SEXE=?");
                String mot = tfRechercher_joueurs.getText();
                preparedStatement.setString(1, "%" + mot + "%");
                preparedStatement.setString(2, "%" + mot + "%");
                preparedStatement.setString(3, sexe);
                System.out.println(sexe);
                ResultSet rs = preparedStatement.executeQuery();
                while(rs.next()){
                    model_Joueurs.insertRow(model_Joueurs.getRowCount(), new Object[] {rs.getInt("ID"), rs.getString("NOM"), rs.getString("PRENOM"), rs.getString("SEXE")});
                }
            }
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erreur d'enregistrement réessayer");
            System.err.println(e);
        }
    }//GEN-LAST:event_tfRechercher_joueursKeyTyped

    private void tfNom_tournoisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfNom_tournoisActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfNom_tournoisActionPerformed

    private void tfCode_tournoisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfCode_tournoisActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfCode_tournoisActionPerformed

    private void btAjouter_tournoisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAjouter_tournoisActionPerformed
        try{
            PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("INSERT INTO tournoi (NOM, CODE) VALUES (?, ?)");
            
            preparedStatement.setString(1, tfNom_tournois.getText());
            preparedStatement.setString(2, tfCode_tournois.getText());
            preparedStatement.executeUpdate();
            
            preparedStatement = conn.getConnexion().prepareStatement("SELECT MAX(ID) FROM tournoi"); //Je recupère l'id le plus élevé soit le dernier tournoi enregistré
            ResultSet rs = preparedStatement.executeQuery();
            if (rs.next()){
                int id = rs.getInt(1);
                model_Tournois.insertRow(model_Tournois.getRowCount(), new Object[] {id, tfNom_tournois.getText(), tfCode_tournois.getText()});
            }
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erreur d'enregistrement réessayer");
            System.err.println(e);
    }
    }//GEN-LAST:event_btAjouter_tournoisActionPerformed

    private void btEditer_tournoisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEditer_tournoisActionPerformed
        try{

            int ligneSelect = tb_Tournois.getSelectedRow();
            String idString = String.valueOf(tb_Tournois.getValueAt(ligneSelect, 0));
            int id = Integer.parseInt(idString);
            PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("UPDATE tournoi SET NOM=?, CODE=? WHERE ID=?");
            
            String nom = tfNom_tournois.getText();
            String code = tfCode_tournois.getText();
                
            preparedStatement.setString(1, nom);
            preparedStatement.setString(2, code);
            preparedStatement.setInt(3, id);
                
            preparedStatement.executeUpdate();
            
            model_Tournois.setValueAt(tfNom_tournois.getText(), tb_Tournois.getSelectedRow(), 1);
            model_Tournois.setValueAt(tfCode_tournois.getText(), tb_Tournois.getSelectedRow(), 2);
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erreur d'enregistrement réessayer");
            System.err.println(e);
        }
    }//GEN-LAST:event_btEditer_tournoisActionPerformed

    private void btSupprimer_tournoisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSupprimer_tournoisActionPerformed
        try{
            int ligneSelect = tb_Tournois.getSelectedRow();
            String idString = String.valueOf(tb_Tournois.getValueAt(ligneSelect, 0));
            int id = Integer.parseInt(idString);
            PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("DELETE FROM tournoi WHERE ID=? ");
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
            
            model_Tournois.removeRow(tb_Tournois.getSelectedRow());
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erreur d'enregistrement réessayer");
            System.err.println(e);
        }
    }//GEN-LAST:event_btSupprimer_tournoisActionPerformed

    private void tfRechercher_tournoisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfRechercher_tournoisActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfRechercher_tournoisActionPerformed

    private void tfRechercher_tournoisKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfRechercher_tournoisKeyTyped
        try{
            //Effacer les lignes du tableau actuel
            DefaultTableModel model_Tournois = (DefaultTableModel)tb_Tournois.getModel();
            model_Tournois.setRowCount(0);
                    
            PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("SELECT * FROM tournoi WHERE NOM LIKE ? OR CODE LIKE ?");
            String mot = tfRechercher_tournois.getText();
            preparedStatement.setString(1, "%" + mot + "%");
            preparedStatement.setString(2, "%" + mot + "%");
            ResultSet rs = preparedStatement.executeQuery();
            
            while(rs.next()){
                model_Tournois.insertRow(model_Tournois.getRowCount(), new Object[] {rs.getInt("ID"), rs.getString("NOM"), rs.getString("CODE")});
            }
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erreur d'enregistrement réessayer");
            System.err.println(e);
        }
    }//GEN-LAST:event_tfRechercher_tournoisKeyTyped

    private void tb_JoueursMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_JoueursMouseClicked

        tfNom_joueurs.setText(String.valueOf(model_Joueurs.getValueAt(tb_Joueurs.getSelectedRow(), 1)));
        tfPrenom_joueurs.setText(String.valueOf(model_Joueurs.getValueAt(tb_Joueurs.getSelectedRow(), 2)));
        tfSexe_joueurs.setText(String.valueOf(model_Joueurs.getValueAt(tb_Joueurs.getSelectedRow(), 3)));
    }//GEN-LAST:event_tb_JoueursMouseClicked

    private void tb_TournoisMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_TournoisMouseClicked

        tfNom_tournois.setText(String.valueOf(model_Tournois.getValueAt(tb_Tournois.getSelectedRow(), 1)));
        tfCode_tournois.setText(String.valueOf(model_Tournois.getValueAt(tb_Tournois.getSelectedRow(), 2)));
    }//GEN-LAST:event_tb_TournoisMouseClicked

    private void combo_matchsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_matchsActionPerformed
        try{
            //Effacer les lignes du tableau actuel
            DefaultTableModel model_Matchs = (DefaultTableModel)tb_Matchs.getModel();
            model_Matchs.setRowCount(0);
                    
            if(combo_matchs.getSelectedItem().equals("Vainqueurs")){
                PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("SELECT * FROM joueur INNER JOIN match_tennis WHERE joueur.ID = match_tennis.ID_VAINQUEUR;");
                ResultSet rs = preparedStatement.executeQuery();
                while(rs.next()){
                    model_Matchs.insertRow(model_Matchs.getRowCount(), new Object[] {rs.getString("NOM"), rs.getString("PRENOM"), rs.getString("SEXE")});
            }
            }else if (combo_matchs.getSelectedItem().equals("Finalistes")){
                PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("SELECT * FROM joueur INNER JOIN match_tennis WHERE joueur.ID = match_tennis.ID_FINALISTE;");
                ResultSet rs = preparedStatement.executeQuery();
                while(rs.next()){
                    model_Matchs.insertRow(model_Matchs.getRowCount(), new Object[] {rs.getString("NOM"), rs.getString("PRENOM"), rs.getString("SEXE")});
            }
            }
            
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erreur d'enregistrement réessayer");
            System.err.println(e);
        }
    }//GEN-LAST:event_combo_matchsActionPerformed

    private void tfRechercher_matchsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfRechercher_matchsActionPerformed

    }//GEN-LAST:event_tfRechercher_matchsActionPerformed

    private void tfRechercher_matchsKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfRechercher_matchsKeyPressed
            try{
            //Effacer les lignes du tableau actuel
                DefaultTableModel model_Matchs  = (DefaultTableModel)tb_Matchs.getModel();
                model_Matchs.setRowCount(0);
                    
                String statut = (String)combo_matchs.getSelectedItem();
                if( statut.equals("Vainqueurs")) {
                    PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("SELECT NOM, PRENOM, SEXE FROM joueur INNER JOIN match_tennis ON joueur.ID = match_tennis.ID_VAINQUEUR WHERE NOM LIKE ? OR PRENOM LIKE ? ;");
                    String mot = tfRechercher_matchs.getText();
                    preparedStatement.setString(1, "%" + mot + "%");
                    preparedStatement.setString(2, "%" + mot + "%");
                    ResultSet rs = preparedStatement.executeQuery();

                    while(rs.next()){
                        model_Matchs.insertRow(model_Matchs.getRowCount(), new Object[] {rs.getString("NOM"), rs.getString("PRENOM"), rs.getString("SEXE")});
                    }
                
                }else if( statut.equals("Finalistes")){
                    PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("SELECT NOM, PRENOM, SEXE FROM joueur INNER JOIN match_tennis ON joueur.ID = match_tennis.ID_VAINQUEUR WHERE NOM LIKE ? OR PRENOM LIKE ? ;");
                    String mot = tfRechercher_matchs.getText();
                    preparedStatement.setString(1, "%" + mot + "%");
                    preparedStatement.setString(2, "%" + mot + "%");
                    ResultSet rs = preparedStatement.executeQuery();
                
                while(rs.next()){
                    model_Matchs.insertRow(model_Matchs.getRowCount(), new Object[] {rs.getString("NOM"), rs.getString("PRENOM"), rs.getString("SEXE")});
                }
                }

            }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erreur d'enregistrement réessayer");
            System.err.println(e);
            }
    }//GEN-LAST:event_tfRechercher_matchsKeyPressed

    private void tfRechercher_matchsKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfRechercher_matchsKeyTyped

    }//GEN-LAST:event_tfRechercher_matchsKeyTyped

    private void tfRechercher_joueursKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfRechercher_joueursKeyPressed

    }//GEN-LAST:event_tfRechercher_joueursKeyPressed

    private void tfRechercher_tournoisKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfRechercher_tournoisKeyPressed
        try{
            //Effacer les lignes du tableau actuel
            DefaultTableModel model1 = (DefaultTableModel)tb_Joueurs.getModel();
            model1.setRowCount(0);
                    
            PreparedStatement preparedStatement = conn.getConnexion().prepareStatement("SELECT * FROM joueur WHERE NOM LIKE ? OR PRENOM LIKE ?");
            String mot = tfRechercher_joueurs.getText();
            preparedStatement.setString(1, "%" + mot + "%");
            preparedStatement.setString(2, "%" + mot + "%");
            ResultSet rs = preparedStatement.executeQuery();
            
            while(rs.next()){
                model1.insertRow(model1.getRowCount(), new Object[] {rs.getInt("ID"), rs.getString("NOM"), rs.getString("PRENOM"), rs.getString("SEXE")});
            }
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"Erreur d'enregistrement réessayer");
            System.err.println(e);
        }
    }//GEN-LAST:event_tfRechercher_tournoisKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Interface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Interface().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAjouter_joueurs;
    private javax.swing.JButton btAjouter_tournois;
    private javax.swing.JButton btEditer_joueurs;
    private javax.swing.JButton btEditer_tournois;
    private javax.swing.JButton btRechercher_epreuve;
    private javax.swing.JButton btSupprimer_joueurs;
    private javax.swing.JButton btSupprimer_tournois;
    private javax.swing.JComboBox<String> combo_matchs;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel labelAnnee_epreuves;
    private javax.swing.JLabel labelCode_tournois;
    private javax.swing.JLabel labelNom_joueurs;
    private javax.swing.JLabel labelNom_tournois;
    private javax.swing.JLabel labelPrenom_joueurs;
    private javax.swing.JLabel labelRechercher_joueurs;
    private javax.swing.JLabel labelRechercher_matchs;
    private javax.swing.JLabel labelRechercher_tournois;
    private javax.swing.JLabel labelSexe_joueurs;
    private javax.swing.JLabel labelSexe_matchs;
    private javax.swing.JLabel labelStatut_matchs;
    private javax.swing.JLabel lbType_epreuves;
    private javax.swing.JComboBox<String> sexeJoueurs;
    private javax.swing.JTable tbJoueurs;
    private javax.swing.JTable tb_Epreuves;
    private javax.swing.JTable tb_Joueurs;
    private javax.swing.JTable tb_Matchs;
    private javax.swing.JTable tb_Tournois;
    private javax.swing.JTextField tfAnnee_epreuves;
    private javax.swing.JTextField tfCode_tournois;
    private javax.swing.JTextField tfNom_joueurs;
    private javax.swing.JTextField tfNom_tournois;
    private javax.swing.JTextField tfPrenom_joueurs;
    private javax.swing.JTextField tfRechercher_joueurs;
    private javax.swing.JTextField tfRechercher_matchs;
    private javax.swing.JTextField tfRechercher_tournois;
    private javax.swing.JTextField tfSexe_joueurs;
    private javax.swing.JTextField tfType_epreuves;
    // End of variables declaration//GEN-END:variables
}
